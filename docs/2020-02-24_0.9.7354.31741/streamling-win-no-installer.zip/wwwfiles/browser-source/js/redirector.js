﻿var urlTextFile;
var nptServer;

function OnLoad() {
    TryRedirect();
    window.setInterval(function () {
        Retry();
        TryRedirect();
    }, 2000);
}

function Retry() {
    let old = document.getElementById('overlayjs');
    if (old) {
        old.remove();
    }
    
    let script = document.createElement('script');
    script.onload = function () {
        TryRedirect();
    };
    script.id = 'overlayjs';
    script.src = 'js/overlay-location.js';

    document.head.appendChild(script);
}

function TryRedirect() {
    if (typeof npt_url !== 'undefined' && npt_url) {
        nptServer = new Image;
        nptServer.onload = function (e) {
            console.debug("ok, redirecting: " + e.type);
            window.location = npt_url + "?back=1";
        }

        nptServer.onerror = function (e) {
            console.debug("error: " + e.type + " url:" + npt_url);
            nptServer = null;
        };

        nptServer.src = npt_url + "exists.gif";
    }
}



function Retry_no_permission_so_fails() {
    urlTextFile = new XMLHttpRequest();
    urlTextFile.open('GET', 'js/overlay-location.txt');
    urlTextFile.onreadystatechange = function () {
        let url = urlTextFile.responseText;
        if (url) {
            url = trim(url);
            TryRedirect();
        }
    }
    urlTextFile.send();
}
