//var $marqHtml;
//var bounce;
const playState = '-webkit-animation-play-state';
const careValues = ['title', 'artist', 'combinedSimple'];

var selection = 0;
var oldValues = { }

var socket;
var socketTimeout;
var retryingInterval;
var retries = 0;
var connection = 0;

function getSocket() {
    return socket;
}

function startConnecting() {
	connect();
	retryingInterval = window.setInterval(function () {
		if (socket && socket.OPEN) {
			// all good. carry on.
		} else {
			retries++;
			if (retries >= 3 && typeof location.search !== 'undefined' && location.search) {
				var queryDict = {}
				location.search.substr(1).split("&").forEach(function (item) { queryDict[item.split("=")[0]] = item.split("=")[1] })
				if (queryDict["back"]) {
					window.history.back();
				}
				retries = 0;
			} else {
				connect();
			}
		}
	}, 2_500); // TODO: try faster first, then back-off
}

// not used, but could be a useful fallback
function loadJson(file) {

	var jsonFile = new XMLHttpRequest();
	jsonFile.onreadystatechange = function () {
		var json = null;
		if (jsonFile.readyState === XMLHttpRequest.DONE) { 
			if (jsonFile.status == 200) {
				retries = 0;
				json = JSON.parse(jsonFile.responseText);
			}
            //console.log(json);
            //processJson(json);
			processJson({"nowPlaying":json}); //TODO: server should be changed so above works

		}
	}
	jsonFile.open("GET", file, true);
	jsonFile.send(null);
	//document.getElementById("debug").innerHTML = np.data('fading');
}

function loadJson(file) {}

function processJsonMsg(jsonmsgtext) {
	if (jsonmsgtext == null) 
		return;

	var jsonmsg = JSON.parse(jsonmsgtext);

	if ("nowPlaying" in jsonmsg) {
		json = jsonmsg.nowPlaying;

		var changed = false;

		if (json == null)
			json = {};

		if ((json == {}) ^ (oldValues == {})) {
			// new OR old state is {}, but not both
			changed = true;

		} else {
			for (var item of careValues) {
				if (oldValues[item] != json[item]) {
					changed = true;
				}
			}
		}

		oldValues = json;
		if (changed) {
			Updated();
        }
        
	} else if ("userstyle" in jsonmsg) {
		settingObj = jsonmsg["userstyle"];
            
        // set ids like they're rel links
        for (const [setting, value] of Object.entries(settingObj)) {
            //TODO: extra check that it's <link rel="stylesheet">

			//TODO: should avoid changing if same?
			//var oldValue = $("#" + setting).attr("href");
			//if (oldValue != value) {
			//}

			// no longer going to be used:
			$("link#" + setting).attr("href", value); // load css by changing stylesheet link

			$("#" + setting).val(value); // set dropdown
		}

		// reload user css: [TODO: hash/timestamp should be supplied]
		$("link#userstyle").attr("href", "/css/" + Math.random());

		//Updated(); // act like title has been updated (to avoid old title appearing)
         
    } 
}


function updateStart() {
	// adds "not-found" class where needed
	TitleUpdated(0);
}

var UpdateLock = false;
function Updated() { // was: marqueeReset();
	if (UpdateLock == true) { // Was trying to fix a bug that was a copy-paste error elsewhere: probably not needed
		setTimeout(Updated, 100);
		return;
	}

	UpdateLock = true;
	oldSelection = selection;
	selection = (++selection) % 2;

	TitleUpdated(selection);

	var outgoing = $(".npt" + oldSelection); 
	var incoming = $(".npt" + selection);
	
	incoming.addClass("now-playing");
	incoming.removeClass("not-playing");

	outgoing.addClass("not-playing");
	outgoing.removeClass("now-playing");
	
	incoming.css(playState, "running");
	outgoing.css(playState, "running");

	setTimeout(ForgetOldTitle, 1500);
	UpdateLock = false;
    //$('body').toggleClass('paused', $(this).css(playState) === 'paused');
	//new Animation();

}

function TitleUpdated(targetnum) { // was: marqueeReset();
	// go through the values we care about and update their text from "oldValues", and set "not-found" on empty ones.

	// general "not-found"
	$.each(careValues, function(index, key) { 
		//console.log(key + ': ' + oldValues[key]);
		var text = oldValues[key] || "";

		// TODO: have an "if-any" that checks for any "found" classes inside

		//update text
		//long way:
		//$(`.npt${targetnum} .${key}`).each(function () { $(this).text(text); });
		// easy way:
		$(`.npt${targetnum} .${key}`).text(text);

		// add "not-found" class if empty
		if (text == "") {
			// second half is for 
			$(`.npt${targetnum} .if-${key}, .npt${targetnum}.if-${key}`).addClass(`not-found`); // todo: .each  was: no-${key}
		} else {
			$(`.npt${targetnum} .if-${key}, .npt${targetnum}.if-${key}`).removeClass(`not-found`);
		}
	});
}

function ForgetOldTitle() { 
	//if (UpdateLock == true) return; // probably not needed (Fixing an error found elsewhere)

	// make the hidden title the same as the shown one (in case it's revealed)
	// TODO: should probably blank it instead
	hiddenSelection = (selection + 1) % 2;
	TitleUpdated(hiddenSelection); // update "wrong" selection with current values
}


function connect() {
	//var exampleSocket = new WebSocket("ws://localhost:9696/socketserver");\
	if (socket) socket.close();

	socket = new WebSocket("ws://" + location.host + "/socketserver");
	$(window).on('beforeunload', function () {
		if (socket != null) socket.close();
    });

    socket.onmessage = function (event) {
        //console.log(event.data);
        processJsonMsg(event.data);
	}

	socket.onopen = function (event) {
		socketOk = 1;
		//window.clearTimeout(socketTimeout);
		window.clearInterval(retryingInterval);
        //socket.send("hi");

		if (typeof location.search !== 'undefined' && location.search) {
			var queryDict = {}
			location.search.substr(1).split("&").forEach(function (item) { queryDict[item.split("=")[0]] = item.split("=")[1] })
			if (queryDict["demo"]) {
				//socket.send(JSON.stringify({ "demo": "on" }));
				//console.log("demo");
				socket.send("demo");
			}
		}

	}

	socket.onclose = function(e) {
		//console.log('Socket is closed. Reconnect will be attempted in 1 second.', e.reason);
		
		//clear "now playing"
		//processJsonMsg(JSON.stringify({ "nowPlaying": {}})); //TODO: somewhat inefficient
		//window.clearTimeout(socketTimeout);

		oldValues = {};
		Updated();

		socket = null;
		
	};
	
	socket.onerror = function(err) {
	//console.error('Socket encountered error: ', err.message, 'Closing socket');
		if (socket) {
			socket.close();
			socket = null;
		}
	};
}

function Start() {
	//marqHtml = $("#npt").clone().html(); // keep a backup so can restart it
    //polling alternative to socket
    //window.setInterval(function() { loadJson('/current'); }, 1000);
	//clearInterval(); // to stop refreshing

	updateStart(); 
	startConnecting();
}
function sendToServer(json) {
    //console.log("AsdfdAS");
    socket.send(json);
} 